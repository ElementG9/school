public class Test {
    public static void main(String[] args) {
        Point p1 = new Point(1,1);
        Point p2 = new Point(4,5);
        Line l1 = new Line(p1,p2);
        
    }
}